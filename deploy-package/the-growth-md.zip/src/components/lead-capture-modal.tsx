"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowRight, Download, Mail } from "lucide-react";
import Link from "next/link";

export function LeadCaptureModal({ trigger, additionalRevenue = 0, currentRevenue = 0 }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [role, setRole] = useState("");
  const [facilitySize, setFacilitySize] = useState("");
  const [optIn, setOptIn] = useState(true);
  const [submitted, setSubmitted] = useState(false);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!name || !email) return;

    // In a real app, you would submit this data to your CRM or backend
    console.log("Lead captured:", { name, email, phone, company, role, facilitySize, optIn });

    // Set submitted to true to show success message
    setSubmitted(true);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        {trigger}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        {!submitted ? (
          <>
            <DialogHeader>
              <DialogTitle className="text-xl">Get Your Detailed ROI Analysis</DialogTitle>
              <DialogDescription>
                We'll email you a comprehensive ROI report showing how you can increase revenue by {formatCurrency(additionalRevenue)}.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name*</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email*</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company">Facility Name</Label>
                  <Input
                    id="company"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="role">Your Role</Label>
                  <Select value={role} onValueChange={setRole}>
                    <SelectTrigger id="role">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="owner">Owner/CEO</SelectItem>
                      <SelectItem value="executive">Executive</SelectItem>
                      <SelectItem value="clinical">Clinical Director</SelectItem>
                      <SelectItem value="admissions">Admissions Director</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="operations">Operations</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="facility-size">Facility Size</Label>
                  <Select value={facilitySize} onValueChange={setFacilitySize}>
                    <SelectTrigger id="facility-size">
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-10">1-10 beds</SelectItem>
                      <SelectItem value="11-25">11-25 beds</SelectItem>
                      <SelectItem value="26-50">26-50 beds</SelectItem>
                      <SelectItem value="51-100">51-100 beds</SelectItem>
                      <SelectItem value="100+">100+ beds</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-start space-x-2 pt-2">
                <Checkbox
                  id="opt-in"
                  checked={optIn}
                  onCheckedChange={setOptIn}
                />
                <Label htmlFor="opt-in" className="text-sm leading-tight">
                  I agree to receive ROI reports, insights, and offers from The Growth MD. You can unsubscribe at any time.
                </Label>
              </div>

              <DialogFooter className="pt-4">
                <Button type="submit" className="w-full">
                  Get My ROI Analysis <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </DialogFooter>
            </form>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="text-xl text-green-600 dark:text-green-400">ROI Analysis On Its Way!</DialogTitle>
              <DialogDescription>
                We've sent your detailed ROI analysis to {email}. Check your inbox in the next few minutes.
              </DialogDescription>
            </DialogHeader>
            <div className="p-6 text-center space-y-6">
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-100 dark:border-green-800">
                <p className="font-medium text-slate-900 dark:text-white">Potential Revenue Increase</p>
                <p className="text-3xl font-bold text-green-600 dark:text-green-400">{formatCurrency(additionalRevenue)}</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {currentRevenue > 0 ? `${Math.round((additionalRevenue / currentRevenue) * 100)}% growth potential` : ''}
                </p>
              </div>

              <div className="space-y-2">
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  The next step is to schedule your personalized assessment with one of our behavioral health consultants.
                </p>

                <div className="flex gap-2">
                  <Button asChild className="flex-1" variant="outline" size="sm">
                    <Link href="/assessment">
                      Schedule Assessment
                    </Link>
                  </Button>
                  <Button className="flex-1" size="sm">
                    <Download className="mr-1 h-3.5 w-3.5" />
                    Download Report
                  </Button>
                </div>
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
