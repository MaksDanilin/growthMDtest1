"use client";

import { useState } from "react";
import Link from "next/link";
import { X, Calculator, PhoneCall, Mail, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

export function FloatingActionButton() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2">
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.2, delay: 0.2 }}
              className="mb-2"
            >
              <Button
                asChild
                variant="secondary"
                size="sm"
                className="shadow-lg flex items-center gap-2 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700"
              >
                <Link href="/roi-calculator">
                  <Calculator className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                  <span>ROI Calculator</span>
                </Link>
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.2, delay: 0.1 }}
              className="mb-2"
            >
              <Button
                asChild
                variant="secondary"
                size="sm"
                className="shadow-lg flex items-center gap-2 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700"
              >
                <Link href="/assessment">
                  <Mail className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                  <span>Free Assessment</span>
                </Link>
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.2 }}
              className="mb-2"
            >
              <Button
                asChild
                variant="secondary"
                size="sm"
                className="shadow-lg flex items-center gap-2 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700"
              >
                <Link href="/contact">
                  <PhoneCall className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                  <span>Contact Us</span>
                </Link>
              </Button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <Button
        onClick={toggleMenu}
        variant="default"
        size="icon"
        className={cn(
          "h-12 w-12 rounded-full shadow-lg bg-indigo-600 hover:bg-indigo-700",
          isOpen && "bg-slate-800 hover:bg-slate-900"
        )}
      >
        {isOpen ? (
          <X className="h-5 w-5" />
        ) : (
          <ChevronUp className="h-5 w-5" />
        )}
      </Button>
    </div>
  );
}
