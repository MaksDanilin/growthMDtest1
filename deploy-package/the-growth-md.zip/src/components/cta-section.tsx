import Link from "next/link";
import { Button } from "./ui/button";

export function CtaSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container-md">
        <div className="rounded-2xl bg-primary p-8 md:p-12 lg:p-16">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="mb-4 text-3xl font-bold tracking-tight text-white md:text-4xl font-heading">
              Ready to Accelerate Your Facility's Growth?
            </h2>
            <p className="mb-8 text-lg text-white/80">
              Book a free consultation with our behavioral health growth specialists to
              discuss your facility's unique challenges and opportunities.
            </p>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link href="/contact">
                <Button size="lg" variant="secondary">
                  Book a Free Consultation
                </Button>
              </Link>
              <Link href="/assessment">
                <Button size="lg" variant="outline" className="bg-transparent text-white hover:bg-white/10 border-white">
                  Get Your Free Assessment
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
