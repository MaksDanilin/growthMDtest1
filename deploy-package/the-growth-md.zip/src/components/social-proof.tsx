"use client";

import { useState, useEffect } from "react";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import {
  Users,
  TrendingUp,
  BarChart,
  Clock,
  CheckCircle,
  Building,
  Bookmark
} from "lucide-react";

interface SocialProofItem {
  icon: React.ElementType;
  value: string;
  label: string;
  color: "primary" | "secondary" | "accent" | "default";
  isAnimated?: boolean;
}

const PROOF_ITEMS: SocialProofItem[] = [
  {
    icon: Users,
    value: "150+",
    label: "Facilities Served",
    color: "primary",
    isAnimated: true
  },
  {
    icon: TrendingUp,
    value: "35%",
    label: "Avg. Revenue Growth",
    color: "secondary"
  },
  {
    icon: BarChart,
    value: "98%",
    label: "Client Satisfaction",
    color: "accent"
  },
  {
    icon: Clock,
    value: "24h",
    label: "Response Time",
    color: "default"
  },
  {
    icon: CheckCircle,
    value: "125",
    label: "Assessments Completed",
    color: "primary",
    isAnimated: true
  },
  {
    icon: Building,
    value: "15+",
    label: "Years of Experience",
    color: "secondary"
  },
  {
    icon: Bookmark,
    value: "54",
    label: "Resources Available",
    color: "accent",
    isAnimated: true
  }
];

export function SocialProof() {
  const [currentItems, setCurrentItems] = useState<SocialProofItem[]>([]);

  // Randomly select 4 items to display
  useEffect(() => {
    // Shuffle array and take first 4
    const shuffled = [...PROOF_ITEMS].sort(() => 0.5 - Math.random());
    setCurrentItems(shuffled.slice(0, 4));

    // Rotate items every 30 seconds
    const interval = setInterval(() => {
      const shuffled = [...PROOF_ITEMS].sort(() => 0.5 - Math.random());
      setCurrentItems(shuffled.slice(0, 4));
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  // Simulate a "live" counter for animated items
  const [counters, setCounters] = useState<Record<string, number>>({});

  useEffect(() => {
    // Initialize counters
    const initialCounters: Record<string, number> = {};

    currentItems.forEach(item => {
      if (item.isAnimated) {
        // Extract the numeric part of the value
        const baseValue = Number.parseInt(item.value.replace(/\D/g, ""));
        initialCounters[item.label] = baseValue;
      }
    });

    setCounters(initialCounters);

    // Increment animated counters
    const interval = setInterval(() => {
      setCounters(prev => {
        const newCounters = { ...prev };

        Object.keys(newCounters).forEach(key => {
          // Randomly increment by 0 or 1
          if (Math.random() > 0.6) {
            newCounters[key] += 1;
          }
        });

        return newCounters;
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [currentItems]);

  // Get display value (use counter for animated items)
  const getDisplayValue = (item: SocialProofItem) => {
    if (item.isAnimated && counters[item.label]) {
      // Replace the numeric part with the counter value
      const prefix = item.value.match(/^\D+/)?.[0] || "";
      const suffix = item.value.match(/\D+$/)?.[0] || "";
      return `${prefix}${counters[item.label]}${suffix}`;
    }
    return item.value;
  };

  const getColorClasses = (color: SocialProofItem["color"]) => {
    switch (color) {
      case "primary":
        return "bg-primary/10 text-primary border-primary/20";
      case "secondary":
        return "bg-secondary/10 text-secondary border-secondary/20";
      case "accent":
        return "bg-accent/10 text-accent border-accent/20";
      default:
        return "bg-muted text-muted-foreground border-muted-foreground/20";
    }
  };

  if (currentItems.length === 0) return null;

  return (
    <div className="fixed bottom-24 left-6 z-40 space-y-2 max-w-[270px]">
      {currentItems.map((item, index) => (
        <Card
          key={`${item.label}-${index}`}
          className={`border shadow-md overflow-hidden transition-all duration-500 ${
            getColorClasses(item.color)
          }`}
        >
          <CardContent className="p-3 flex items-center gap-3">
            <div className="h-8 w-8 rounded-full bg-background/50 flex items-center justify-center">
              <item.icon className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-bold leading-none">
                {getDisplayValue(item)}
                {item.isAnimated && (
                  <Badge
                    variant="outline"
                    className="ml-1.5 text-[10px] px-1 py-0 bg-background/50 border-none"
                  >
                    Live
                  </Badge>
                )}
              </div>
              <div className="text-xs opacity-90">{item.label}</div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
