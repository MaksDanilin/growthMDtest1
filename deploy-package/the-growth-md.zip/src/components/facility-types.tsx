import Link from "next/link";
import { Card, CardContent } from "./ui/card";
import { ArrowRight } from "lucide-react";

const facilityTypes = [
  {
    title: "Treatment Centers",
    description: "Tailored growth strategies for residential and inpatient treatment facilities, focusing on census building and sustainable growth.",
    href: "/facility-types/treatment-centers",
  },
  {
    title: "Detox Centers",
    description: "Specialized support for medical detoxification programs, with focus on operational efficiency and high-quality referral networks.",
    href: "/facility-types/detox-centers",
  },
  {
    title: "PHP/IOP Programs",
    description: "Growth solutions for partial hospitalization and intensive outpatient programs to optimize admissions and clinical outcomes.",
    href: "/facility-types/php-iop-programs",
  },
  {
    title: "Outpatient Services",
    description: "Strategic approaches for traditional outpatient behavioral health practices to increase patient volume and retention.",
    href: "/facility-types/outpatient-services",
  },
  {
    title: "Specialty Programs",
    description: "Custom growth strategies for specialized behavioral health services, including eating disorder treatment, trauma therapy, and more.",
    href: "/facility-types/specialty-programs",
  },
];

export function FacilityTypes() {
  return (
    <section className="py-16 md:py-24 bg-muted/30">
      <div className="container-md">
        <div className="mb-12 text-center">
          <h2 className="section-heading font-heading">
            Specialized Solutions for Every Type of Facility
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-muted-foreground">
            We understand the unique challenges facing different behavioral health modalities.
            Our growth strategies are tailored to your specific type of facility.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {facilityTypes.map((facility) => (
            <Link key={facility.title} href={facility.href} className="group">
              <Card className="h-full transition-all hover:shadow-md hover:border-primary/50">
                <CardContent className="p-6">
                  <h3 className="mb-2 text-xl font-bold">{facility.title}</h3>
                  <p className="mb-4 text-muted-foreground">{facility.description}</p>
                  <div className="flex items-center text-sm font-medium text-primary">
                    Learn more
                    <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
