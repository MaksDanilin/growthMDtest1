import Link from "next/link";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { ArrowRight, BarChart2, Users, Settings, LineChart } from "lucide-react";

// Updated services with distinctive title formatting - added v4 to force update
const services = [
  {
    title: "Revenue Optimization v4",
    description: "Maximize your facility's financial performance with strategic billing, insurance optimization, and financial operations improvement.",
    icon: <BarChart2 className="h-10 w-10 text-primary" />,
    href: "/services/revenue-optimization",
  },
  {
    title: "Patient Acquisition v4",
    description: "Create predictable patient flow with targeted marketing, referral programs, and outreach strategies specific to behavioral health.",
    icon: <Users className="h-10 w-10 text-primary" />,
    href: "/services/patient-acquisition",
  },
  {
    title: "Operational Excellence v4",
    description: "Streamline your operations with proven systems to improve efficiency, reduce costs, and enhance care quality.",
    icon: <Settings className="h-10 w-10 text-primary" />,
    href: "/services/operational-excellence",
  },
  {
    title: "Digital Transformation v4",
    description: "Leverage technology to modernize your practice with EHR optimization, telehealth solutions, and data analytics.",
    icon: <LineChart className="h-10 w-10 text-primary" />,
    href: "/services/digital-transformation",
  },
];

export function ServicesSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container-md">
        <div className="mb-12 text-center">
          <h2 className="section-heading font-heading">
            Services Tailored to Behavioral Health Facilities
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-muted-foreground">
            Our specialized growth services are designed specifically for behavioral health
            facilities and programs, addressing the unique challenges of the industry.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((service) => (
            <Card key={service.title} className="h-full transition-all hover:shadow-md">
              <CardHeader>
                <div className="mb-4">{service.icon}</div>
                <CardTitle>{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">{service.description}</CardDescription>
              </CardContent>
              <CardFooter>
                <Link href={service.href} className="group flex items-center gap-1 text-sm font-medium text-primary">
                  Learn more
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link href="/services">
            <Button variant="outline" size="lg">
              View All Services
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
