import Image from 'next/image';

export function TrustedBy() {
  return (
    <section className="py-16 bg-slate-50 dark:bg-slate-900">
      <div className="container mx-auto px-4">
        <h2 className="text-center text-2xl font-bold text-slate-900 dark:text-white mb-10">
          TRUSTED BY LEADING BEHAVIORAL HEALTH FACILITIES
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 items-center justify-items-center">
          {/* Guardian Recovery */}
          <div className="w-full max-w-[200px] h-[80px] relative">
            <Image
              src="/logos/guardian-recovery.png"
              alt="Guardian Recovery"
              fill
              style={{ objectFit: 'contain' }}
              className="transition hover:opacity-80"
            />
          </div>

          {/* Mountainside */}
          <div className="w-full max-w-[200px] h-[80px] relative">
            <Image
              src="/logos/mountainside.png"
              alt="Mountainside"
              fill
              style={{ objectFit: 'contain' }}
              className="transition hover:opacity-80"
            />
          </div>

          {/* Aware Recovery */}
          <div className="w-full max-w-[200px] h-[80px] relative">
            <Image
              src="/logos/aware-recovery.png"
              alt="Aware Recovery Care"
              fill
              style={{ objectFit: 'contain' }}
              className="transition hover:opacity-80"
            />
          </div>

          {/* Empower Health */}
          <div className="w-full max-w-[200px] h-[80px] relative">
            <Image
              src="/logos/empower-health.png"
              alt="Empower Health"
              fill
              style={{ objectFit: 'contain' }}
              className="transition hover:opacity-80"
            />
          </div>

          {/* Additional Placeholder - Remove or replace with the Flyland logo */}
          <div className="w-full max-w-[200px] h-[80px] relative flex items-center justify-center border border-slate-200 dark:border-slate-700 rounded-lg">
            <span className="text-lg font-medium text-slate-600 dark:text-slate-400">Your Logo Here</span>
          </div>
        </div>

        <p className="text-center text-slate-600 dark:text-slate-400 mt-12 text-sm italic max-w-2xl mx-auto">
          We've helped these and many other behavioral health facilities increase revenue, improve census,
          and optimize operations. Let us help you grow your facility with proven strategies.
        </p>
      </div>
    </section>
  );
}
