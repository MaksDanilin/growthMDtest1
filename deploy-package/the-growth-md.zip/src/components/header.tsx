import Link from "next/link";
import { Button } from "./ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { cn } from "@/lib/utils";
import { ThemeToggle } from "./theme-toggle";

const services = [
  {
    title: "Revenue Optimization",
    href: "/services/revenue-optimization",
    description: "Maximize your facility's revenue through strategic billing, insurance optimization, and financial operations improvement."
  },
  {
    title: "Patient Acquisition",
    href: "/services/patient-acquisition",
    description: "Create predictable patient flow with targeted marketing, referral programs, and outreach strategies."
  },
  {
    title: "Operational Excellence",
    href: "/services/operational-excellence",
    description: "Streamline your operations with proven systems to improve efficiency, reduce costs, and enhance care quality."
  },
  {
    title: "Clinical Program Development",
    href: "/services/clinical-program-development",
    description: "Design evidence-based treatment programs that improve outcomes and differentiate your facility."
  },
  {
    title: "Compliance & Accreditation",
    href: "/services/compliance-accreditation",
    description: "Navigate regulatory requirements and achieve accreditation standards with confidence."
  }
];

const healthcareTypes = [
  {
    title: "Treatment Centers",
    href: "/facility-types/treatment-centers",
    description: "Growth strategies for residential and inpatient treatment facilities."
  },
  {
    title: "Detox Centers",
    href: "/facility-types/detox-centers",
    description: "Specialized support for medical detoxification programs."
  },
  {
    title: "PHP/IOP Programs",
    href: "/facility-types/php-iop-programs",
    description: "Tailored solutions for partial hospitalization and intensive outpatient programs."
  },
  {
    title: "Outpatient Services",
    href: "/facility-types/outpatient-services",
    description: "Growth strategies for traditional outpatient behavioral health practices."
  },
  {
    title: "Specialty Programs",
    href: "/facility-types/specialty-programs",
    description: "Custom approaches for specialized behavioral health services."
  }
];

const ListItem = ({
  className,
  title,
  href,
  children,
}: {
  className?: string;
  title: string;
  href: string;
  children: React.ReactNode;
}) => {
  return (
    <li>
      <NavigationMenuLink asChild>
        <Link
          href={href}
          className={cn(
            "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
            className
          )}
        >
          <div className="text-sm font-medium leading-none">{title}</div>
          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
            {children}
          </p>
        </Link>
      </NavigationMenuLink>
    </li>
  );
};

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6 md:gap-10">
          <Link href="/" className="hidden items-center space-x-2 md:flex">
            <span className="font-heading text-2xl font-bold">The Growth MD</span>
          </Link>

          {/* Mobile Logo */}
          <Link href="/" className="flex items-center md:hidden">
            <span className="font-heading text-xl font-bold">TGM</span>
          </Link>

          <NavigationMenu className="hidden md:flex">
            <NavigationMenuList>
              <NavigationMenuItem>
                <NavigationMenuTrigger>Services</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                    {services.map((service) => (
                      <ListItem
                        key={service.title}
                        title={service.title}
                        href={service.href}
                      >
                        {service.description}
                      </ListItem>
                    ))}
                    <div className="col-span-2 mt-3 pt-3 border-t border-border text-center">
                      <Link href="/services" className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline">
                        View All Services →
                      </Link>
                    </div>
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>

              <NavigationMenuItem>
                <NavigationMenuTrigger>Facility Types</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                    {healthcareTypes.map((type) => (
                      <ListItem
                        key={type.title}
                        title={type.title}
                        href={type.href}
                      >
                        {type.description}
                      </ListItem>
                    ))}
                    <div className="col-span-2 mt-3 pt-3 border-t border-border text-center">
                      <Link href="/facility-types" className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline">
                        View All Facility Types →
                      </Link>
                    </div>
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>

              <NavigationMenuItem>
                <Link href="/case-studies" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                    Case Studies
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>

              <NavigationMenuItem>
                <Link href="/insights" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                    Insights
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>

              <NavigationMenuItem>
                <Link href="/about" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                    About
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
        </div>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Link href="/assessment" className="hidden md:block">
            <Button variant="outline">Free Assessment</Button>
          </Link>
          <Link href="/contact">
            <Button>Book a Consultation</Button>
          </Link>
        </div>
      </div>
    </header>
  );
}
