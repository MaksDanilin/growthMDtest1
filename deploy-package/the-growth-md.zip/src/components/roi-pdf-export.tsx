"use client";

import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Textarea } from './ui/textarea';
import { usePDF } from 'react-to-pdf';
import { CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { Download, Mail, FileText, BarChart, Users } from 'lucide-react';

// Format currency values
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0
  }).format(value);
};

// Format percentage values
const formatPercent = (value: string | number) => {
  const numValue = typeof value === 'string' ? Number.parseFloat(value) : value;
  return `${numValue > 0 ? '+' : ''}${numValue}%`;
};

interface ROIPdfExportProps {
  containerRef?: React.RefObject<HTMLDivElement>;
  additionalData: {
    currentRevenue: number;
    projectedRevenue: number;
    percentIncrease: string;
  };
}

export function ROIPdfExport({ containerRef, additionalData }: ROIPdfExportProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    facilityName: '',
    role: '',
    includeInDepthAnalysis: true,
    includeImplementationPlan: true,
    includeMarketingInsights: false,
    message: '',
  });

  const [showThankYou, setShowThankYou] = useState(false);

  // Use the usePDF hook from react-to-pdf
  const { toPDF, targetRef } = usePDF({
    filename: 'growth-md-roi-analysis.pdf',
    page: {
      margin: 20,
      format: 'letter',
      orientation: 'portrait'
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData(prev => ({ ...prev, [name]: checked }));
  };

  const handlePdfDownload = () => {
    if (targetRef.current) {
      toPDF();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, this would submit to a backend API
    console.log('Form submitted:', formData);
    // Show thank you message
    setShowThankYou(true);

    // Reset after 3 seconds
    setTimeout(() => {
      setShowThankYou(false);
    }, 3000);
  };

  // Calculate additional values for the PDF
  const totalBenefit = additionalData.projectedRevenue - additionalData.currentRevenue;
  const roi = Math.round(totalBenefit / 20000); // Assuming standard consulting cost

  return (
    <div>
      <Button
        onClick={handlePdfDownload}
        variant="ghost"
        size="sm"
        className="flex items-center gap-1"
      >
        <Download className="h-4 w-4" />
        Export PDF
      </Button>

      {/* PDF Content - Hidden but used for export */}
      <div className="hidden">
        <div
          ref={targetRef}
          className="p-6 border rounded-md bg-white text-black w-[800px]"
        >
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-indigo-600">
              Behavioral Health ROI Analysis
            </h2>
            <p className="text-sm text-gray-600">
              Prepared by The Growth MD
            </p>
          </div>

          <div className="mb-6">
            <h3 className="text-md font-medium flex items-center border-b pb-2 mb-3">
              <BarChart className="h-4 w-4 mr-2 text-indigo-600" />
              Financial Impact Summary
            </h3>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="p-3 bg-slate-50 rounded-md">
                <div className="text-sm text-gray-600">
                  Annual Revenue Impact
                </div>
                <div className="text-xl font-bold text-indigo-600">
                  {formatCurrency(totalBenefit)}
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-md">
                <div className="text-sm text-gray-600">
                  Return on Investment
                </div>
                <div className="text-xl font-bold text-indigo-600">
                  {roi}x
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="text-sm font-medium mb-1">Current Revenue</h4>
                <p className="text-lg">{formatCurrency(additionalData.currentRevenue)}</p>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-1">Projected Revenue</h4>
                <p className="text-lg">{formatCurrency(additionalData.projectedRevenue)}</p>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-1">Percent Increase</h4>
                <p className="text-lg">{formatPercent(additionalData.percentIncrease)}</p>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-1">Implementation Period</h4>
                <p className="text-lg">3-6 months</p>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-md font-medium flex items-center border-b pb-2 mb-3">
              <Users className="h-4 w-4 mr-2 text-indigo-600" />
              Growth Opportunities
            </h3>

            <div className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span>Census improvement</span>
                <span className="font-medium">+10-15%</span>
              </div>

              <div className="flex justify-between items-center text-sm">
                <span>Reimbursement optimization</span>
                <span className="font-medium">+8-12%</span>
              </div>

              <div className="flex justify-between items-center text-sm">
                <span>Length of stay optimization</span>
                <span className="font-medium">+5-10%</span>
              </div>

              <div className="flex justify-between items-center text-sm">
                <span>Lead conversion improvement</span>
                <span className="font-medium">+10-15%</span>
              </div>

              <div className="flex justify-between items-center text-sm">
                <span>Operational savings</span>
                <span className="font-medium">+6-10%</span>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-md font-medium flex items-center border-b pb-2 mb-3">
              <FileText className="h-4 w-4 mr-2 text-indigo-600" />
              Implementation & ROI Timeline
            </h3>

            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>Implementation Period</span>
                <span className="font-medium">3-4 months</span>
              </div>

              <div className="flex justify-between text-sm">
                <span>Full Benefit Realization</span>
                <span className="font-medium">10-12 months</span>
              </div>

              <div className="flex justify-between text-sm">
                <span>Investment Payback Period</span>
                <span className="font-medium">4-6 months</span>
              </div>
            </div>
          </div>

          <div className="text-xs text-gray-500 mt-10">
            <p>This analysis is based on the information provided and industry benchmarks. Results may vary based on implementation quality and market conditions.</p>
            <p className="mt-1">For a detailed growth plan customized to your facility, please contact us at info@thegrowthmd.com or (888) 555-0123.</p>
            <p className="mt-6 text-center">© {new Date().getFullYear()} The Growth MD • www.thegrowthmd.com</p>
          </div>
        </div>
      </div>
    </div>
  );
}
