# Deploying to Vercel

This guide provides detailed instructions for deploying your Next.js project to Vercel. Vercel is the platform created by the team behind Next.js and offers the best deployment experience for Next.js applications.

## Why Vercel?

- **Built for Next.js**: Vercel is created by the same team that developed Next.js
- **Zero configuration**: Automatic detection and configuration of your Next.js app
- **Global CDN**: Fast content delivery with edge caching
- **Automatic HTTPS**: Secure SSL certificates out of the box
- **Preview deployments**: Every Git branch/PR gets its own preview deployment
- **Serverless functions**: Built-in support for API routes and server components
- **Environment variables**: Secure storage of environment variables and secrets

## Deployment Options

### Option 1: Deploy via GitHub Integration (Recommended)

This method is the easiest and provides the best continuous integration workflow.

1. **Push your code to GitHub**
   - Create a GitHub repository
   - Push your Next.js project to the repository

2. **Connect to Vercel**
   - Go to [https://vercel.com/new](https://vercel.com/new)
   - Sign up or log in (can use your GitHub account)
   - Select "Import Git Repository"
   - Choose your GitHub repository

3. **Configure your project**
   - Vercel will automatically detect Next.js and suggest optimal settings
   - Configure framework preset: Next.js
   - Build Command: `npm run build` (or whatever is in your package.json)
   - Output Directory: `out` (since we're using static export)
   - Add environment variables if needed

4. **Deploy**
   - Click "Deploy"
   - Vercel will build and deploy your application
   - You'll receive a production URL when done (e.g., your-project.vercel.app)

### Option 2: Deploy with Vercel CLI

For more command-line control or for deployment outside of Git workflows.

1. **Install Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Login to Vercel**
   ```bash
   vercel login
   ```

3. **Deploy**
   ```bash
   # Navigate to your project directory
   cd your-project-directory

   # Deploy to production
   vercel --prod
   ```

4. **Or use our included script**
   ```bash
   ./deploy-vercel.sh
   ```

## Post-Deployment Steps

### 1. Set up a custom domain (optional)
- Go to your project in the Vercel dashboard
- Click "Domains"
- Add your custom domain and follow the verification instructions

### 2. Set up environment variables (if needed)
- Go to your project in the Vercel dashboard
- Click "Settings" > "Environment Variables"
- Add your production environment variables

### 3. Configure project settings (if needed)
- Build & Development Settings: Adjust build commands if needed
- Environment Variables: Add any required variables
- Integrations: Connect analytics, monitoring, etc.

## Troubleshooting

### Build Failures
- Check build logs in Vercel dashboard
- Ensure all dependencies are correctly listed in package.json
- Verify your Next.js configuration is valid for Vercel

### Missing or Incorrect Assets
- Check that all assets are properly referenced with relative paths
- Verify images and other assets are properly handled
- Adjust the `next.config.js` as needed

### Performance Issues
- Use Vercel Analytics to identify slow pages
- Check core web vitals in the Vercel dashboard
- Consider implementing ISR (Incremental Static Regeneration) for frequently updated content

## Further Resources

- [Vercel Documentation](https://vercel.com/docs)
- [Next.js Deployment Guide](https://nextjs.org/docs/deployment)
- [Vercel CLI Documentation](https://vercel.com/docs/cli)
