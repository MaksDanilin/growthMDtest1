interface Asset {
  href: string;
  as?: string;
  type: 'font' | 'style' | 'script' | 'image';
  crossOrigin?: string;
  importance?: 'high' | 'low' | 'auto';
}

// Define critical assets that should be preloaded
export const criticalAssets: Asset[] = [
  // Fonts
  {
    href: 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
    type: 'style',
  },
  // Images - header logo, hero background, etc.
  {
    href: '/images/grid-pattern.svg',
    type: 'image',
  },
  // Logos for "Trusted By" section
  {
    href: '/logos/mountainside.png',
    type: 'image',
  },
  {
    href: '/logos/aware-recovery.png',
    type: 'image',
  },
  {
    href: '/logos/guardian-recovery.png',
    type: 'image',
  },
  {
    href: '/logos/empower-health.png',
    type: 'image',
  },
];

/**
 * Generates HTML preload link tags based on the provided assets
 * @param assets Array of assets to preload
 * @returns Array of preload link tag HTML strings
 */
export function generatePreloadLinks(assets: Asset[]): string[] {
  return assets.map((asset) => {
    const { href, as, type, crossOrigin, importance } = asset;

    let asValue = as;
    if (!asValue) {
      if (type === 'image') asValue = 'image';
      else if (type === 'style') asValue = 'style';
      else if (type === 'script') asValue = 'script';
      else if (type === 'font') asValue = 'font';
    }

    let linkType;
    if (href.endsWith('.svg')) linkType = 'image/svg+xml';
    else if (href.endsWith('.png')) linkType = 'image/png';
    else if (href.endsWith('.jpg') || href.endsWith('.jpeg')) linkType = 'image/jpeg';
    else if (href.endsWith('.css')) linkType = 'text/css';
    else if (href.endsWith('.js')) linkType = 'text/javascript';

    let link = `<link rel="preload" href="${href}" as="${asValue}"`;

    if (linkType) link += ` type="${linkType}"`;
    if (crossOrigin) link += ` crossOrigin="${crossOrigin}"`;
    if (importance) link += ` importance="${importance}"`;

    link += '>';

    return link;
  });
}
