"use client";

import { useState, useEffect } from "react";
import { MessageSquare, X, Send, Loader2 } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";

interface Message {
  sender: "user" | "agent";
  text: string;
  timestamp: Date;
}

export function LiveChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isAgentTyping, setIsAgentTyping] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [hasUnreadMessages, setHasUnreadMessages] = useState(false);

  // Simulate business hours (9am-5pm, Monday-Friday)
  useEffect(() => {
    const checkBusinessHours = () => {
      const now = new Date();
      const day = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
      const hour = now.getHours();

      // Check if it's a weekday (Monday-Friday) and between 9am-5pm
      return day >= 1 && day <= 5 && hour >= 9 && hour < 17;
    };

    setIsOnline(checkBusinessHours());

    // Check every minute
    const interval = setInterval(() => {
      setIsOnline(checkBusinessHours());
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  // Add initial welcome message
  useEffect(() => {
    if (messages.length === 0 && isOpen) {
      const initialMessage = {
        sender: "agent" as const,
        text: "Hello! Thanks for reaching out to The Growth MD. How can we help you today?",
        timestamp: new Date()
      };
      setMessages([initialMessage]);
    }
  }, [isOpen, messages.length]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    // Add user message
    const userMessage: Message = {
      sender: "user",
      text: newMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage("");

    // Simulate agent typing
    setIsAgentTyping(true);

    // Simulate agent response after a delay
    setTimeout(() => {
      // Sample responses
      const responses = [
        "That's a great question about our services. We specialize in helping behavioral health facilities increase revenue and optimize operations. Would you like to schedule a free consultation to discuss your specific needs?",
        "I'd be happy to help with that. Our team has extensive experience working with facilities like yours. Can you tell me a bit more about your current challenges?",
        "Thank you for your interest! I'll connect you with one of our growth specialists who can provide more detailed information. Would you prefer to continue this conversation over email or phone?",
        "We have several case studies from similar facilities that achieved significant growth. I can share those with you if you'd like to see specific results."
      ];

      const randomResponse = responses[Math.floor(Math.random() * responses.length)];

      // Add agent message
      const agentMessage: Message = {
        sender: "agent",
        text: randomResponse,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, agentMessage]);
      setIsAgentTyping(false);
    }, 1500 + Math.random() * 1500); // Random delay between 1.5-3s
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Set unread indicator when receiving messages while chat is closed
  useEffect(() => {
    if (!isOpen && messages.length > 0 && messages[messages.length - 1].sender === "agent") {
      setHasUnreadMessages(true);
    }
  }, [messages, isOpen]);

  return (
    <>
      {/* Floating chat button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => {
            setIsOpen(!isOpen);
            if (!isOpen) setHasUnreadMessages(false);
          }}
          className="h-14 w-14 rounded-full shadow-lg relative"
          size="icon"
        >
          {isOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <MessageSquare className="h-6 w-6" />
          )}
          {!isOpen && hasUnreadMessages && (
            <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-destructive"></span>
          )}
        </Button>
      </div>

      {/* Chat window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-80 md:w-96">
          <Card className="shadow-xl border-primary/10">
            <CardHeader className="bg-primary text-primary-foreground p-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/logos/growth-md-icon.png" alt="The Growth MD" />
                    <AvatarFallback>GM</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-base">The Growth MD</CardTitle>
                    <div className="flex items-center mt-0.5">
                      <span className={`h-2 w-2 rounded-full ${isOnline ? 'bg-green-400' : 'bg-yellow-400'} mr-1.5`}></span>
                      <span className="text-xs font-medium">{isOnline ? 'Online' : 'Away'}</span>
                    </div>
                  </div>
                </div>
                <Badge variant="outline" className="bg-white/10 hover:bg-white/20 text-white border-none">
                  {isOnline ? 'Chat Now' : 'Leave a Message'}
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="p-4 h-80 overflow-y-auto flex flex-col gap-3">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.sender === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                    <div className="text-xs opacity-70 mt-1 text-right">
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              ))}
              {isAgentTyping && (
                <div className="flex justify-start">
                  <div className="max-w-[80%] bg-muted rounded-lg p-3">
                    <div className="flex items-center gap-1">
                      <div className="h-2 w-2 rounded-full bg-foreground/60 animate-bounce"></div>
                      <div className="h-2 w-2 rounded-full bg-foreground/60 animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      <div className="h-2 w-2 rounded-full bg-foreground/60 animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>

            <CardFooter className="p-4 pt-2 border-t">
              <div className="flex gap-2 w-full">
                <Textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Type your message..."
                  className="min-h-[40px] resize-none"
                  rows={1}
                />
                <Button
                  className="shrink-0"
                  size="icon"
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim()}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </CardFooter>
          </Card>
        </div>
      )}
    </>
  );
}
