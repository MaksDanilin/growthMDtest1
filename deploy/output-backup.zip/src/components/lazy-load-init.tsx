"use client";

import { useEffect } from "react";

export default function LazyLoadInit() {
  useEffect(() => {
    // Load LazyLoad script
    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/vanilla-lazyload@17.8.4/dist/lazyload.min.js";
    script.async = true;
    script.defer = true;
    script.id = "lazyload-script";

    script.onload = () => {
      // Initialize LazyLoad after script loads
      if (typeof window !== "undefined" && "LazyLoad" in window) {
        try {
          // @ts-ignore
          new window.LazyLoad({
            elements_selector: ".lazy",
            threshold: 300,
          });
        } catch (e) {
          console.error("Error initializing LazyLoad:", e);
        }
      }
    };

    // Only add the script if it doesn't already exist
    if (!document.getElementById("lazyload-script")) {
      document.body.appendChild(script);
    }

    return () => {
      // Clean up if component unmounts
      if (document.getElementById("lazyload-script") === script) {
        document.body.removeChild(script);
      }
    };
  }, []);

  return null;
}
