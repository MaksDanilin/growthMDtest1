"use client";

import { useEffect, useRef } from "react";

interface DeferredScriptProps {
  src: string;
  id?: string;
  priority?: "low" | "medium" | "high";
  defer?: boolean;
  async?: boolean;
  "data-testid"?: string;
}

// Using useRef instead of useState to avoid re-renders
export function DeferredScript({
  src,
  id,
  priority = "low",
  async = true,
  defer = true,
  "data-testid": dataTestId,
}: DeferredScriptProps) {
  const loadedRef = useRef(false);
  const cleanupRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    // Skip if already loaded
    if (document.getElementById(id || src) || loadedRef.current) {
      return;
    }

    const loadScript = () => {
      const script = document.createElement("script");
      script.src = src;
      script.async = async;
      script.defer = defer;

      if (id) script.id = id;
      if (dataTestId) script.setAttribute("data-testid", dataTestId);

      script.onload = () => {
        loadedRef.current = true;

        // Special handling for lazyload script
        if (id === "lazyload-script" && typeof window !== "undefined") {
          try {
            // @ts-ignore
            new window.LazyLoad({
              elements_selector: ".lazy",
              threshold: 300,
            });
          } catch (e) {
            console.error("Error initializing LazyLoad:", e);
          }
        }
      };

      document.body.appendChild(script);
    };

    let cleanup: (() => void) | null = null;

    // Determine when to load based on priority
    switch (priority) {
      case "high":
        // Load immediately
        loadScript();
        break;
      case "medium":
        // Load after page is interactive
        if (document.readyState === "complete") {
          loadScript();
        } else {
          window.addEventListener("load", loadScript);
          cleanup = () => window.removeEventListener("load", loadScript);
        }
        break;
      case "low":
      default:
        // Load after a delay when the main thread is idle
        const timeoutId = setTimeout(() => {
          if ("requestIdleCallback" in window) {
            // @ts-ignore - requestIdleCallback is not in the TypeScript DOM types
            window.requestIdleCallback(loadScript);
          } else {
            setTimeout(loadScript, 1000);
          }
        }, 2000);

        cleanup = () => clearTimeout(timeoutId);
    }

    // Store cleanup function
    cleanupRef.current = cleanup;

    // Cleanup function
    return () => {
      if (cleanupRef.current) {
        cleanupRef.current();
      }
    };
  }, [src, id, priority, async, defer, dataTestId]);

  return null;
}
