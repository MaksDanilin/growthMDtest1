"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useMemo } from 'react';

// Format currency values
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0
  }).format(value);
};

interface ROIChartsProps {
  currentRevenue: number;
  projectedRevenue: number;
  censusImprovement: number;
  reimbursementImprovement: number;
  losImprovement: number;
  conversionImprovement: number;
  operationsImprovement: number;
  currentCensus: number;
  avgDailyRate: number;
}

export function ROICharts({
  currentRevenue,
  projectedRevenue,
  censusImprovement,
  reimbursementImprovement,
  losImprovement,
  conversionImprovement,
  operationsImprovement,
  currentCensus,
  avgDailyRate
}: ROIChartsProps) {
  const [activeChart, setActiveChart] = useState('revenue');

  // Calculate total benefit
  const totalBenefit = censusImprovement + reimbursementImprovement + losImprovement +
    conversionImprovement + operationsImprovement;

  // Revenue comparison data
  const revenueComparisonData = useMemo(() => [
    { name: 'Current', value: currentRevenue },
    { name: 'Projected', value: projectedRevenue }
  ], [currentRevenue, projectedRevenue]);

  // Breakdown data for pie chart
  const improvementBreakdownData = useMemo(() => {
    const data = [];

    // Add breakdown items if they exist
    if (censusImprovement > 0) {
      data.push({
        name: 'Census Improvement',
        value: censusImprovement
      });
    }

    if (reimbursementImprovement > 0) {
      data.push({
        name: 'Reimbursement',
        value: reimbursementImprovement
      });
    }

    if (losImprovement > 0) {
      data.push({
        name: 'Length of Stay',
        value: losImprovement
      });
    }

    if (conversionImprovement > 0) {
      data.push({
        name: 'Lead Conversion',
        value: conversionImprovement
      });
    }

    if (operationsImprovement > 0) {
      data.push({
        name: 'Operations',
        value: operationsImprovement
      });
    }

    return data;
  }, [censusImprovement, reimbursementImprovement, losImprovement, conversionImprovement, operationsImprovement]);

  // Monthly projection data
  const monthlyProjectionData = useMemo(() => {
    // Create 12 months of data
    return Array.from({ length: 12 }, (_, i) => {
      // For first 3 months, show implementation period with minimal gains
      // Then gradually increase to full benefit by month 10
      const month = i + 1;
      let growthFactor = 0;

      if (month <= 3) {
        growthFactor = 0.1 * month; // 10%, 20%, 30% in first 3 months
      } else if (month <= 10) {
        growthFactor = 0.3 + (month - 3) * 0.1; // 40% to 100% from month 4 to 10
      } else {
        growthFactor = 1.0; // 100% for months 11 and 12
      }

      const monthlyBenefit = totalBenefit / 12 * growthFactor;
      const baseRevenue = currentRevenue / 12;

      return {
        name: `Month ${month}`,
        revenue: baseRevenue + monthlyBenefit,
        baseline: baseRevenue
      };
    });
  }, [currentRevenue, totalBenefit]);

  // Key metrics comparison
  const metricsComparisonData = useMemo(() => [
    {
      name: 'Census',
      current: currentCensus,
      projected: Math.min(currentCensus + 15, 100),
      unit: '%'
    },
    {
      name: 'Daily Rate',
      current: avgDailyRate,
      projected: avgDailyRate * 1.1,
      unit: '$'
    },
    {
      name: 'Revenue',
      current: currentRevenue,
      projected: projectedRevenue,
      unit: '$'
    }
  ], [currentCensus, avgDailyRate, currentRevenue, projectedRevenue]);

  // Custom tooltip formatter
  const customTooltipFormatter = (value: number, name: string, entry: any) => {
    if (entry.unit === '%') {
      return [`${value.toFixed(1)}%`, name];
    } else if (entry.unit === '$') {
      return [`$${value}`, name];
    } else {
      return [value, name];
    }
  };

  // Colors for pie chart
  const COLORS = ['#3b82f6', '#10b981', '#6366f1', '#f59e0b', '#ef4444'];

  return (
    <div className="space-y-4">
      <Tabs value={activeChart} onValueChange={setActiveChart} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="breakdown">Breakdown</TabsTrigger>
          <TabsTrigger value="projection">Projection</TabsTrigger>
          <TabsTrigger value="metrics">Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="revenue" className="pt-4">
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={revenueComparisonData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis
                  tickFormatter={(value) => value >= 1000000
                    ? `$${(value / 1000000).toFixed(1)}M`
                    : value >= 1000
                    ? `$${(value / 1000).toFixed(0)}K`
                    : `$${value}`
                  }
                />
                <Tooltip
                  formatter={(value) => [formatCurrency(value as number), 'Revenue']}
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.9)',
                    borderColor: '#e2e8f0',
                    borderRadius: '6px'
                  }}
                />
                <Legend />
                <Bar dataKey="value" name="Annual Revenue" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="text-sm text-muted-foreground mt-2">
            Compare your current annual revenue with projected revenue after implementing our recommended growth strategies.
          </div>
        </TabsContent>

        <TabsContent value="breakdown" className="pt-4">
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={improvementBreakdownData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                  label={(entry) => `${entry.name}: ${formatCurrency(entry.value)}`}
                >
                  {improvementBreakdownData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [formatCurrency(value as number), 'Amount']} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="text-sm text-muted-foreground mt-2">
            Breakdown of total financial benefit between direct revenue growth and operational cost savings.
          </div>
        </TabsContent>

        <TabsContent value="projection" className="pt-4">
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={monthlyProjectionData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis
                  tickFormatter={(value) => value >= 1000000
                    ? `$${(value / 1000000).toFixed(1)}M`
                    : value >= 1000
                    ? `$${(value / 1000).toFixed(0)}K`
                    : `$${value}`
                  }
                />
                <Tooltip
                  formatter={(value) => [formatCurrency(value as number), 'Revenue']}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  name="Projected Revenue"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  activeDot={{ r: 8 }}
                />
                <Line
                  type="monotone"
                  dataKey="baseline"
                  name="Baseline Revenue"
                  stroke="#94a3b8"
                  strokeDasharray="5 5"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="text-sm text-muted-foreground mt-2">
            Projected monthly revenue growth over the next 12 months showing implementation timeline.
          </div>
        </TabsContent>

        <TabsContent value="metrics" className="pt-4">
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={metricsComparisonData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                barGap={0}
                barCategoryGap="25%"
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis
                  tickFormatter={(value) => {
                    // Dynamic tick formatter based on metric type
                    const metric = metricsComparisonData.find(m =>
                      m.current <= value && m.projected >= value ||
                      m.current >= value && m.projected <= value
                    );

                    if (!metric) return value;

                    if (metric.unit === '%') return `${value}%`;
                    if (metric.unit === '$') return `$${value}`;
                    return value;
                  }}
                />
                <Tooltip
                  formatter={(value, name, entry) => customTooltipFormatter(value as number, name as string, entry)}
                />
                <Legend />
                <Bar dataKey="current" name="Current" fill="#94a3b8" radius={[4, 4, 0, 0]} />
                <Bar dataKey="projected" name="Projected" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="text-sm text-muted-foreground mt-2">
            Comparison of key performance metrics before and after optimization.
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
