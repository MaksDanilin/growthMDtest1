import Link from "next/link";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Separator } from "./ui/separator";

export function Footer() {
  return (
    <footer className="bg-card">
      <div className="container py-10 md:py-16">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-12">
          <div className="md:col-span-4 lg:col-span-5">
            <div className="mb-6">
              <Link href="/" className="font-heading text-2xl font-bold">
                The Growth MD
              </Link>
              <p className="mt-3 text-muted-foreground">
                Specialized growth consultancy for behavioral health facilities. We help treatment centers,  detox facilities, PHPs, IOPs, and outpatient programs improve revenue, operations, and patient acquisition.
              </p>
            </div>
            <div className="mb-6">
              <h3 className="mb-3 font-medium">Subscribe to Our Newsletter</h3>
              <div className="flex gap-2">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="max-w-xs"
                />
                <Button type="submit">Subscribe</Button>
              </div>
            </div>
          </div>

          <div className="md:col-span-8 lg:col-span-7">
            <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
              <div>
                <h3 className="mb-3 text-lg font-medium">Services</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/services/revenue-optimization" className="text-muted-foreground hover:text-foreground">
                      Revenue Optimization
                    </Link>
                  </li>
                  <li>
                    <Link href="/services/patient-acquisition" className="text-muted-foreground hover:text-foreground">
                      Patient Acquisition
                    </Link>
                  </li>
                  <li>
                    <Link href="/services/operational-excellence" className="text-muted-foreground hover:text-foreground">
                      Operational Excellence
                    </Link>
                  </li>
                  <li>
                    <Link href="/services/clinical-program-development" className="text-muted-foreground hover:text-foreground">
                      Clinical Program Development
                    </Link>
                  </li>
                  <li>
                    <Link href="/services" className="text-muted-foreground hover:text-foreground font-medium">
                      View All Services →
                    </Link>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="mb-3 text-lg font-medium">Facility Types</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/facility-types/treatment-centers" className="text-muted-foreground hover:text-foreground">
                      Treatment Centers
                    </Link>
                  </li>
                  <li>
                    <Link href="/facility-types/detox-centers" className="text-muted-foreground hover:text-foreground">
                      Detox Centers
                    </Link>
                  </li>
                  <li>
                    <Link href="/facility-types/php-iop-programs" className="text-muted-foreground hover:text-foreground">
                      PHP/IOP Programs
                    </Link>
                  </li>
                  <li>
                    <Link href="/facility-types/outpatient-services" className="text-muted-foreground hover:text-foreground">
                      Outpatient Services
                    </Link>
                  </li>
                  <li>
                    <Link href="/facility-types/specialty-programs" className="text-muted-foreground hover:text-foreground">
                      Specialty Programs
                    </Link>
                  </li>
                  <li>
                    <Link href="/facility-types" className="text-muted-foreground hover:text-foreground font-medium">
                      View All Facility Types →
                    </Link>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="mb-3 text-lg font-medium">Company</h3>
                <ul className="space-y-2">
                  <li>
                    <Link href="/about" className="text-muted-foreground hover:text-foreground">
                      About Us
                    </Link>
                  </li>
                  <li>
                    <Link href="/case-studies" className="text-muted-foreground hover:text-foreground">
                      Case Studies
                    </Link>
                  </li>
                  <li>
                    <Link href="/insights" className="text-muted-foreground hover:text-foreground">
                      Insights
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="text-muted-foreground hover:text-foreground">
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-8" />

        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} The Growth MD. All rights reserved.
          </div>

          <div className="flex gap-4">
            <Link href="/privacy-policy" className="text-sm text-muted-foreground hover:text-foreground">
              Privacy Policy
            </Link>
            <Link href="/terms-of-service" className="text-sm text-muted-foreground hover:text-foreground">
              Terms of Service
            </Link>
          </div>

          <div className="flex gap-4">
            <Link href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5 text-muted-foreground hover:text-foreground"
              >
                <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
              </svg>
            </Link>
            <Link href="https://linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5 text-muted-foreground hover:text-foreground"
              >
                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                <rect width="4" height="12" x="2" y="9" />
                <circle cx="4" cy="4" r="2" />
              </svg>
            </Link>
            <Link href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5 text-muted-foreground hover:text-foreground"
              >
                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
              </svg>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
