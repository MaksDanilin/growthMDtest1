"use client";

import { type FC, useRef } from "react";
import { usePDF } from "react-to-pdf";
import { Download, FileText, BadgeCheck, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BenchmarkingPdfExportProps {
  facilityType: string;
  metricValues: Record<string, number>;
  scores: {
    financial: number;
    operational: number;
    clinical: number;
    satisfaction: number;
  };
  recommendations: {
    financial: string[];
    operational: string[];
    clinical: string[];
    satisfaction: string[];
  };
}

const formatValue = (value: number | undefined, type: string) => {
  if (!value && value !== 0) return 'N/A';

  switch (type) {
    case 'currency':
      return `$${value.toLocaleString()}`;
    case 'percentage':
      return `${value}%`;
    case 'days':
      return `${value} days`;
    default:
      return value.toString();
  }
};

const formatDate = () => {
  const date = new Date();
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
};

const BenchmarkingPdfExport: FC<BenchmarkingPdfExportProps> = ({
  facilityType,
  metricValues,
  scores,
  recommendations
}) => {
  const targetRef = useRef<HTMLDivElement>(null);
  const { toPDF, targetRef: pdfRef } = usePDF({
    filename: `behavioral-health-benchmarking-report-${new Date().toISOString().slice(0, 10)}.pdf`,
  });

  const displayFacilityType = facilityType === ''
    ? 'All Facility Types'
    : facilityType
        .replace('-', '/')
        .replace('residential', 'Residential Treatment')
        .replace('detox', 'Detox Center')
        .replace('php-iop', 'PHP/IOP Program')
        .replace('outpatient', 'Outpatient Services')
        .replace('specialty', 'Specialty Program');

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-blue-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Good';
    if (score >= 40) return 'Average';
    return 'Below Average';
  };

  return (
    <>
      <Button onClick={() => toPDF()} className="gap-2">
        <Download className="h-4 w-4" />
        Download PDF Report
      </Button>

      {/* Hidden PDF content */}
      <div className="hidden">
        <div ref={pdfRef} className="p-8 bg-white text-black" style={{ width: '800px' }}>
          {/* Header */}
          <div className="flex justify-between items-center mb-6 border-b pb-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Behavioral Health Benchmarking Report</h1>
              <p className="text-gray-600">Generated on {formatDate()}</p>
            </div>
            <div className="flex items-center">
              <FileText className="h-8 w-8 text-primary mr-2" />
              <span className="text-xl font-semibold text-primary">The Growth MD</span>
            </div>
          </div>

          {/* Facility Info */}
          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-2">Facility Information</h2>
            <p><strong>Facility Type:</strong> {displayFacilityType}</p>
          </div>

          {/* Performance Summary */}
          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-4">Performance Summary</h2>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="border rounded p-3">
                <h3 className="font-medium">Financial Performance</h3>
                <div className="flex justify-between items-center mt-2">
                  <span className={`text-xl font-bold ${getScoreColor(scores.financial)}`}>
                    {scores.financial.toFixed(0)}%
                  </span>
                  <span className={`text-sm ${getScoreColor(scores.financial)}`}>
                    {getScoreLabel(scores.financial)}
                  </span>
                </div>
              </div>

              <div className="border rounded p-3">
                <h3 className="font-medium">Operational Performance</h3>
                <div className="flex justify-between items-center mt-2">
                  <span className={`text-xl font-bold ${getScoreColor(scores.operational)}`}>
                    {scores.operational.toFixed(0)}%
                  </span>
                  <span className={`text-sm ${getScoreColor(scores.operational)}`}>
                    {getScoreLabel(scores.operational)}
                  </span>
                </div>
              </div>

              <div className="border rounded p-3">
                <h3 className="font-medium">Clinical Performance</h3>
                <div className="flex justify-between items-center mt-2">
                  <span className={`text-xl font-bold ${getScoreColor(scores.clinical)}`}>
                    {scores.clinical.toFixed(0)}%
                  </span>
                  <span className={`text-sm ${getScoreColor(scores.clinical)}`}>
                    {getScoreLabel(scores.clinical)}
                  </span>
                </div>
              </div>

              <div className="border rounded p-3">
                <h3 className="font-medium">Satisfaction Performance</h3>
                <div className="flex justify-between items-center mt-2">
                  <span className={`text-xl font-bold ${getScoreColor(scores.satisfaction)}`}>
                    {scores.satisfaction.toFixed(0)}%
                  </span>
                  <span className={`text-sm ${getScoreColor(scores.satisfaction)}`}>
                    {getScoreLabel(scores.satisfaction)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Top Recommendations */}
          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-4">Key Recommendations</h2>

            {Object.entries(recommendations).map(([category, recs]) => (
              <div key={category} className="mb-4">
                <h3 className="font-medium capitalize mb-2">
                  {category === 'financial' ? 'Financial' :
                   category === 'operational' ? 'Operational' :
                   category === 'clinical' ? 'Clinical' : 'Satisfaction'} Recommendations
                </h3>
                <ul className="space-y-2">
                  {recs.map((rec, i) => (
                    <li key={i} className="flex gap-2">
                      {rec.includes("meets or exceeds") ? (
                        <BadgeCheck className="h-5 w-5 text-green-600 flex-shrink-0" />
                      ) : (
                        <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0" />
                      )}
                      <span className="text-sm">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="mt-8 border-t pt-4 text-sm text-gray-600">
            <p>This report provides a summary of your facility's performance compared to industry benchmarks. For a more detailed analysis and personalized recommendations, contact The Growth MD at contact@thegrowthmd.com</p>
            <p className="mt-2">&copy; {new Date().getFullYear()} The Growth MD. All rights reserved.</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default BenchmarkingPdfExport;
