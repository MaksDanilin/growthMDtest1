export function Stats() {
  return (
    <section className="py-16 md:py-24 bg-primary text-white">
      <div className="container-md">
        <div className="text-center mb-12">
          <h2 className="section-heading font-heading text-white">
            Our Proven Impact in Behavioral Health
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-white/80">
            We've helped hundreds of behavioral health facilities across the country achieve
            sustainable growth and improved operational performance.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-lg bg-white/10 p-6 text-center">
            <p className="text-4xl font-bold md:text-5xl">35%</p>
            <p className="mt-2 text-white/80">Average Census Increase</p>
          </div>

          <div className="rounded-lg bg-white/10 p-6 text-center">
            <p className="text-4xl font-bold md:text-5xl">28%</p>
            <p className="mt-2 text-white/80">Higher Insurance Reimbursements</p>
          </div>

          <div className="rounded-lg bg-white/10 p-6 text-center">
            <p className="text-4xl font-bold md:text-5xl">42%</p>
            <p className="mt-2 text-white/80">Improved Operational Efficiency</p>
          </div>

          <div className="rounded-lg bg-white/10 p-6 text-center">
            <p className="text-4xl font-bold md:text-5xl">93%</p>
            <p className="mt-2 text-white/80">Client Satisfaction Rate</p>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-sm text-white/60">
            *Results based on average client performance across our portfolio of 100+ behavioral health clients.
          </p>
        </div>
      </div>
    </section>
  );
}
