"use client";

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ROICalculatorForm } from './roi-calculator-form';
import { ROIVisualization } from './roi-visualization';
import { ROICharts } from './roi-charts';
import { ROIPdfExport } from './roi-pdf-export';
import { Calculator, ArrowRight, FileText, ChevronRight, BarChart, Briefcase } from 'lucide-react';

export function ROICalculatorHome() {
  const [activeTab, setActiveTab] = useState('calculator');
  const [results, setResults] = useState<any>(null);
  const [isClient, setIsClient] = useState(false);

  // Ensure we're rendering on client-side for React components that require window
  useEffect(() => {
    setIsClient(true);
  }, []);

  const handleCalculate = (values: any) => {
    // This is where we calculate the ROI
    const {
      facilityType,
      bedCapacity,
      currentCensus,
      avgDailyRate,
      avgLOS,
      optimizeCensus,
      optimizeReimbursement,
      optimizeConversion,
      optimizeLOS,
      optimizeOperations
    } = values;

    // Calculate current revenue and projections
    const daysPerYear = 365;
    const currentOccupancy = currentCensus / 100;
    const currentPatientDays = bedCapacity * currentOccupancy * daysPerYear;
    const currentRevenue = currentPatientDays * avgDailyRate;
    const currentPatients = currentPatientDays / avgLOS;

    // Calculate optimized values
    const censusImprovement = optimizeCensus ? 0.15 : 0;
    const rateImprovement = optimizeReimbursement ? 0.10 : 0;
    const conversionImprovement = optimizeConversion ? 0.12 : 0;
    const losImprovement = optimizeLOS ? 0.05 : 0;
    const operationalSavings = optimizeOperations ? 0.08 : 0;

    // Calculate projected revenue
    const projectedOccupancy = Math.min(0.95, currentOccupancy * (1 + censusImprovement));
    const projectedDailyRate = avgDailyRate * (1 + rateImprovement);
    const projectedLOS = avgLOS * (1 + losImprovement);
    const projectedPatientDays = bedCapacity * projectedOccupancy * daysPerYear;
    const projectedRevenue = projectedPatientDays * projectedDailyRate;
    const admissionsIncrease = conversionImprovement;
    const projectedPatients = currentPatients * (1 + admissionsIncrease);

    // Calculate operational savings
    const currentOperationalCost = currentRevenue * 0.65; // Assuming operational costs are 65% of revenue
    const operationalSavingsAmount = currentOperationalCost * operationalSavings;

    // Calculate ROI
    const revenueIncrease = projectedRevenue - currentRevenue;
    const totalBenefit = revenueIncrease + operationalSavingsAmount;
    const investmentCost = calculateInvestmentCost(bedCapacity, facilityType);
    const roi = totalBenefit / investmentCost;

    // Prepare results object
    const calculatedResults = {
      current: {
        occupancy: currentOccupancy * 100,
        patientDays: Math.round(currentPatientDays),
        dailyRate: avgDailyRate,
        revenue: Math.round(currentRevenue),
        patients: Math.round(currentPatients),
        operationalCost: Math.round(currentOperationalCost),
      },
      projected: {
        occupancy: projectedOccupancy * 100,
        patientDays: Math.round(projectedPatientDays),
        dailyRate: Math.round(projectedDailyRate),
        revenue: Math.round(projectedRevenue),
        patients: Math.round(projectedPatients),
        operationalCost: Math.round(currentOperationalCost - operationalSavingsAmount),
      },
      improvement: {
        occupancy: (projectedOccupancy - currentOccupancy) * 100,
        patientDays: Math.round(projectedPatientDays - currentPatientDays),
        dailyRate: Math.round(projectedDailyRate - avgDailyRate),
        revenue: Math.round(projectedRevenue - currentRevenue),
        operationalSavings: Math.round(operationalSavingsAmount),
        patients: Math.round(projectedPatients - currentPatients),
      },
      totalBenefit: Math.round(totalBenefit),
      investmentCost: Math.round(investmentCost),
      roi: Number.parseFloat(roi.toFixed(2)),
      paybackPeriod: Number.parseFloat((investmentCost / (totalBenefit / 12)).toFixed(1)), // in months
      values: values // Store original input values
    };

    setResults(calculatedResults);
    setActiveTab('results');
  };

  // Helper function to estimate a realistic investment cost based on facility size
  function calculateInvestmentCost(bedCapacity: number, facilityType: string) {
    let baseCost = 30000; // Base consulting cost

    // Adjust based on facility type
    switch (facilityType) {
      case 'residential':
        baseCost = 35000;
        break;
      case 'detox':
        baseCost = 40000;
        break;
      case 'php-iop':
        baseCost = 28000;
        break;
      case 'outpatient':
        baseCost = 25000;
        break;
      case 'specialty':
        baseCost = 38000;
        break;
    }

    // Scale based on bed capacity
    if (bedCapacity <= 15) {
      return baseCost * 0.8;
    } else if (bedCapacity <= 30) {
      return baseCost;
    } else if (bedCapacity <= 50) {
      return baseCost * 1.3;
    } else if (bedCapacity <= 100) {
      return baseCost * 1.6;
    } else {
      return baseCost * 2;
    }
  }

  if (!isClient) {
    return null; // Return nothing on first server render
  }

  return (
    <div className="container py-12">
      <div className="flex items-center gap-1 text-sm text-muted-foreground mb-8">
        <Link href="/" className="hover:text-foreground">Home</Link>
        <ChevronRight className="h-4 w-4" />
        <span>ROI Calculator</span>
      </div>

      <div className="mx-auto mb-16 max-w-3xl text-center">
        <div className="bg-primary/10 text-primary font-medium px-3 py-1 rounded-full text-sm inline-flex items-center mb-4">
          <Calculator className="h-3.5 w-3.5 mr-1.5" />
          <span>Free Growth Calculator</span>
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-4 font-heading">
          Calculate Your Facility's <span className="text-gradient animate-gradient bg-[length:300%_300%]">Growth Potential</span>
        </h1>
        <p className="text-xl text-muted-foreground">
          Discover how our specialized consulting services can impact your behavioral health facility's
          revenue, census, and operational efficiency.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        <Card className="bg-primary/5 border border-primary/20">
          <CardHeader>
            <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
              <BarChart className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Revenue Impact</CardTitle>
            <CardDescription>
              See how optimized reimbursement rates and increased census can boost your revenue
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2 mt-0.5">
                  <ChevronRight className="h-3 w-3 text-primary" />
                </div>
                <span className="text-sm">Daily rate optimization</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2 mt-0.5">
                  <ChevronRight className="h-3 w-3 text-primary" />
                </div>
                <span className="text-sm">Census improvement strategies</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2 mt-0.5">
                  <ChevronRight className="h-3 w-3 text-primary" />
                </div>
                <span className="text-sm">Payer mix enhancement</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-accent/5 border border-accent/20">
          <CardHeader>
            <div className="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center mb-2">
              <Briefcase className="h-6 w-6 text-accent" />
            </div>
            <CardTitle>Operational Efficiency</CardTitle>
            <CardDescription>
              Identify cost-saving opportunities while maintaining quality care
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-accent/10 flex items-center justify-center mr-2 mt-0.5">
                  <ChevronRight className="h-3 w-3 text-accent" />
                </div>
                <span className="text-sm">Staffing optimization</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-accent/10 flex items-center justify-center mr-2 mt-0.5">
                  <ChevronRight className="h-3 w-3 text-accent" />
                </div>
                <span className="text-sm">Process improvement</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-accent/10 flex items-center justify-center mr-2 mt-0.5">
                  <ChevronRight className="h-3 w-3 text-accent" />
                </div>
                <span className="text-sm">Resource utilization</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-secondary/10 border border-secondary/20">
          <CardHeader>
            <div className="h-12 w-12 rounded-full bg-secondary/20 flex items-center justify-center mb-2">
              <FileText className="h-6 w-6 text-secondary" />
            </div>
            <CardTitle>Data-Driven Insights</CardTitle>
            <CardDescription>
              Get detailed projections and visualizations of potential growth
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-secondary/20 flex items-center justify-center mr-2 mt-0.5">
                  <ChevronRight className="h-3 w-3 text-secondary" />
                </div>
                <span className="text-sm">Financial forecasting</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-secondary/20 flex items-center justify-center mr-2 mt-0.5">
                  <ChevronRight className="h-3 w-3 text-secondary" />
                </div>
                <span className="text-sm">ROI calculations</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-secondary/20 flex items-center justify-center mr-2 mt-0.5">
                  <ChevronRight className="h-3 w-3 text-secondary" />
                </div>
                <span className="text-sm">Exportable PDF reports</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="mx-auto max-w-5xl">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="calculator">Calculator</TabsTrigger>
          <TabsTrigger value="results" disabled={!results}>Results</TabsTrigger>
          <TabsTrigger value="export" disabled={!results}>Export</TabsTrigger>
        </TabsList>

        <TabsContent value="calculator" className="space-y-4">
          <ROICalculatorForm onCalculate={handleCalculate} initialValues={results?.values} />
        </TabsContent>

        <TabsContent value="results" className="space-y-8">
          {results && (
            <>
              <div className="grid grid-cols-1 gap-6">
                <Card className="shadow-md">
                  <CardHeader>
                    <CardTitle className="text-center">ROI Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                      <div className="text-center p-4 bg-primary/5 rounded-md">
                        <div className="text-2xl font-bold text-primary lg:text-3xl">{results.roi}x</div>
                        <div className="text-sm text-muted-foreground">Return on Investment</div>
                      </div>
                      <div className="text-center p-4 bg-accent/5 rounded-md">
                        <div className="text-2xl font-bold text-accent lg:text-3xl">${(results.totalBenefit / 1000).toFixed(0)}K</div>
                        <div className="text-sm text-muted-foreground">Annual Financial Benefit</div>
                      </div>
                      <div className="text-center p-4 bg-secondary/5 rounded-md">
                        <div className="text-2xl font-bold text-secondary lg:text-3xl">{results.paybackPeriod} mo</div>
                        <div className="text-sm text-muted-foreground">Payback Period</div>
                      </div>
                    </div>

                    <ROIVisualization results={results} />
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Financial Impact</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ROICharts results={results} />
                  </CardContent>
                  <CardFooter className="border-t bg-muted/50 flex justify-between">
                    <div className="text-sm text-muted-foreground">
                      <span className="font-medium">Note:</span> Projections based on industry benchmarks and your input data.
                    </div>
                    <Button variant="ghost" onClick={() => setActiveTab('export')} className="text-sm">
                      Export Results <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="export">
          {results && (
            <Card>
              <CardHeader>
                <CardTitle>Export Your ROI Analysis</CardTitle>
                <CardDescription>Download a detailed PDF report or schedule a consultation to discuss your results</CardDescription>
              </CardHeader>
              <CardContent>
                <ROIPdfExport results={results} />
              </CardContent>
              <CardFooter className="justify-between border-t">
                <Button variant="outline" onClick={() => setActiveTab('results')}>
                  Back to Results
                </Button>
                <Button asChild>
                  <Link href="/contact">Schedule Consultation</Link>
                </Button>
              </CardFooter>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      <div className="mt-16 rounded-xl bg-muted p-8 max-w-3xl mx-auto">
        <h3 className="text-xl font-bold mb-3">How We Calculate Your Growth Potential</h3>
        <p className="text-muted-foreground mb-4">
          Our ROI calculator uses industry benchmarks and proven growth models based on data from over 150 behavioral
          health facilities. The projections account for:
        </p>
        <ul className="space-y-2 mb-6">
          <li className="flex gap-2 items-start">
            <ChevronRight className="h-4 w-4 text-primary mt-1 flex-shrink-0" />
            <span className="text-sm">Facility-specific metrics like bed capacity, current census, and average daily rates</span>
          </li>
          <li className="flex gap-2 items-start">
            <ChevronRight className="h-4 w-4 text-primary mt-1 flex-shrink-0" />
            <span className="text-sm">Targeted improvement areas such as census optimization, reimbursement rates, and operational efficiencies</span>
          </li>
          <li className="flex gap-2 items-start">
            <ChevronRight className="h-4 w-4 text-primary mt-1 flex-shrink-0" />
            <span className="text-sm">Conservative growth estimates validated by real-world results from similar facilities</span>
          </li>
        </ul>
        <div className="text-sm text-muted-foreground">
          <strong>Note:</strong> This calculator provides estimates based on industry averages. A personalized consultation
          will yield more precise projections for your specific facility.
        </div>
      </div>
    </div>
  );
}
