"use client";

import { Card } from "@/components/ui/card";
import { ArrowUpRight, ArrowDownRight, CircleDollarSign, TrendingUp, Users, Calendar } from "lucide-react";

// Format currency values
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0
  }).format(value);
};

// Format percentage values
const formatPercent = (value: number) => {
  return `${value > 0 ? '+' : ''}${value.toFixed(1)}%`;
};

interface ROIVisualizationProps {
  results: {
    current: {
      occupancy: number;
      patientDays: number;
      dailyRate: number;
      revenue: number;
      patients: number;
      operationalCost: number;
    };
    projected: {
      occupancy: number;
      patientDays: number;
      dailyRate: number;
      revenue: number;
      patients: number;
      operationalCost: number;
    };
    improvement: {
      occupancy: number;
      patientDays: number;
      dailyRate: number;
      revenue: number;
      operationalSavings: number;
      patients: number;
    };
    totalBenefit: number;
    investmentCost: number;
    roi: number;
    paybackPeriod: number;
  };
}

export function ROIVisualization({ results }: ROIVisualizationProps) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-4">
          <h3 className="text-base font-medium">Revenue Growth</h3>
          <div className="flex items-center justify-between p-4 bg-white dark:bg-zinc-900 rounded-lg border">
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <CircleDollarSign className="h-5 w-5 text-primary" />
              </div>
              <div>
                <div className="text-sm font-medium">Annual Revenue</div>
                <div className="text-2xl font-bold">{formatCurrency(results.projected.revenue)}</div>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <div className={`flex items-center ${results.improvement.revenue > 0 ? 'text-green-500' : 'text-red-500'}`}>
                {results.improvement.revenue > 0 ? (
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                ) : (
                  <ArrowDownRight className="h-4 w-4 mr-1" />
                )}
                {formatCurrency(results.improvement.revenue)}
              </div>
              <div className="text-xs text-muted-foreground">
                {formatPercent(results.improvement.revenue / results.current.revenue * 100)}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-white dark:bg-zinc-900 rounded-lg border">
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center mr-3">
                <TrendingUp className="h-5 w-5 text-accent" />
              </div>
              <div>
                <div className="text-sm font-medium">Operational Savings</div>
                <div className="text-2xl font-bold">{formatCurrency(results.improvement.operationalSavings)}</div>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <div className="text-xs text-muted-foreground">
                Per Year
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-base font-medium">Key Metrics Improvement</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-white dark:bg-zinc-900 rounded-lg border">
              <div className="flex justify-between items-start mb-2">
                <div className="h-8 w-8 rounded-full bg-violet-100 dark:bg-violet-900 flex items-center justify-center">
                  <Users className="h-4 w-4 text-violet-600 dark:text-violet-400" />
                </div>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                  results.improvement.occupancy > 0 ?
                  'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400' :
                  'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-400'
                }`}>
                  {formatPercent(results.improvement.occupancy)}
                </span>
              </div>
              <div className="text-sm font-medium">Occupancy</div>
              <div className="text-xl font-bold">{results.projected.occupancy.toFixed(1)}%</div>
            </div>

            <div className="p-4 bg-white dark:bg-zinc-900 rounded-lg border">
              <div className="flex justify-between items-start mb-2">
                <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                  <CircleDollarSign className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                </div>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                  results.improvement.dailyRate > 0 ?
                  'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400' :
                  'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-400'
                }`}>
                  {formatPercent(results.improvement.dailyRate / results.current.dailyRate * 100)}
                </span>
              </div>
              <div className="text-sm font-medium">Daily Rate</div>
              <div className="text-xl font-bold">${results.projected.dailyRate}</div>
            </div>

            <div className="p-4 bg-white dark:bg-zinc-900 rounded-lg border">
              <div className="flex justify-between items-start mb-2">
                <div className="h-8 w-8 rounded-full bg-amber-100 dark:bg-amber-900 flex items-center justify-center">
                  <Calendar className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                </div>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                  results.improvement.patientDays > 0 ?
                  'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400' :
                  'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-400'
                }`}>
                  {formatPercent(results.improvement.patientDays / results.current.patientDays * 100)}
                </span>
              </div>
              <div className="text-sm font-medium">Patient Days</div>
              <div className="text-xl font-bold">{results.projected.patientDays.toLocaleString()}</div>
            </div>

            <div className="p-4 bg-white dark:bg-zinc-900 rounded-lg border">
              <div className="flex justify-between items-start mb-2">
                <div className="h-8 w-8 rounded-full bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center">
                  <Users className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                </div>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                  results.improvement.patients > 0 ?
                  'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400' :
                  'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-400'
                }`}>
                  {formatPercent(results.improvement.patients / results.current.patients * 100)}
                </span>
              </div>
              <div className="text-sm font-medium">Patients/Year</div>
              <div className="text-xl font-bold">{results.projected.patients}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <div className="text-sm text-muted-foreground mb-1">Current Annual Revenue</div>
            <div className="text-xl font-medium">{formatCurrency(results.current.revenue)}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground mb-1">Investment Cost</div>
            <div className="text-xl font-medium">{formatCurrency(results.investmentCost)}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground mb-1">Annual Financial Impact</div>
            <div className="text-xl font-medium text-primary">{formatCurrency(results.totalBenefit)}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
