import { Card, CardContent } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { QuoteIcon } from "lucide-react";

const testimonials = [
  {
    id: "testimonial-1",
    quote: "The Growth MD's expertise in behavioral health helped us increase our census by 35% within 6 months. Their specialized approach to our unique market challenges made all the difference.",
    name: "Dr. Sarah Johnson",
    role: "Executive Director, Serenity Treatment Center",
    avatar: "/testimonials/avatar-1.jpg",
    initials: "SJ",
  },
  {
    id: "testimonial-2",
    quote: "Working with The Growth MD transformed our financial operations. Our insurance reimbursement rates improved by 28%, and our billing efficiency increased dramatically.",
    name: "Michael Rodriguez",
    role: "CFO, Hillside Recovery",
    avatar: "/testimonials/avatar-2.jpg",
    initials: "MR",
  },
  {
    id: "testimonial-3",
    quote: "The patient acquisition strategy developed by The Growth MD was a game-changer for our IOP program. We're now consistently at 85% capacity with a qualified waitlist for the first time.",
    name: "Jennifer Chen",
    role: "Clinical Director, Mindful Wellness Center",
    avatar: "/testimonials/avatar-3.jpg",
    initials: "JC",
  },
];

export function Testimonials() {
  return (
    <section className="py-16 md:py-24 bg-secondary">
      <div className="container-md">
        <div className="mb-12 text-center">
          <h2 className="section-heading font-heading">
            Trusted by Leading Behavioral Health Facilities
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-muted-foreground">
            See how we've helped treatment centers, detox facilities, PHPs, and IOPs{" "}
            across the country achieve sustainable growth.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="border-none bg-card/50 backdrop-blur">
              <CardContent className="p-6">
                <QuoteIcon className="mb-4 h-8 w-8 text-primary/50" />
                <blockquote className="mb-6 text-lg">"{testimonial.quote}"</blockquote>
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                    <AvatarFallback>{testimonial.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
