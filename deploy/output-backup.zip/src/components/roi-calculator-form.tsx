"use client";

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Calculator,
  DollarSign,
  Users,
  BarChart,
  TrendingUp,
  Building,
  Info,
  Save,
  Upload,
  RotateCw
} from 'lucide-react';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

// Define the form validation schema with Zod
const calculatorSchema = z.object({
  facilityType: z.string().min(1, { message: "Please select a facility type" }),
  bedCapacity: z.coerce
    .number()
    .min(1, { message: "Capacity must be at least 1" })
    .max(1000, { message: "Capacity must be less than 1000" }),
  currentCensus: z.coerce
    .number()
    .min(1, { message: "Census must be at least 1%" })
    .max(100, { message: "Census cannot exceed 100%" }),
  avgDailyRate: z.coerce
    .number()
    .min(1, { message: "Daily rate must be at least $1" })
    .max(10000, { message: "Daily rate seems too high" }),
  avgLOS: z.coerce
    .number()
    .min(1, { message: "Length of stay must be at least 1 day" })
    .max(365, { message: "Length of stay must be less than 365 days" }),
  optimizeCensus: z.boolean().default(true),
  optimizeReimbursement: z.boolean().default(true),
  optimizeConversion: z.boolean().default(false),
  optimizeLOS: z.boolean().default(false),
  optimizeOperations: z.boolean().default(false),
});

// Define type based on the schema
type CalculatorFormValues = z.infer<typeof calculatorSchema>;

// Default form values
const defaultValues: CalculatorFormValues = {
  facilityType: "residential",
  bedCapacity: 32,
  currentCensus: 75,
  avgDailyRate: 800,
  avgLOS: 30,
  optimizeCensus: true,
  optimizeReimbursement: true,
  optimizeConversion: false,
  optimizeLOS: false,
  optimizeOperations: false,
};

export function ROICalculatorForm({
  onCalculate,
  initialValues = defaultValues
}) {
  // Form state
  const [isLoading, setIsLoading] = useState(false);
  const [hasCalculated, setHasCalculated] = useState(false);
  const [savedCalculations, setSavedCalculations] = useState(() => {
    // Load saved calculations from localStorage if available
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('savedROICalculations');
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });

  // Initialize form with react-hook-form and zod validation
  const form = useForm<CalculatorFormValues>({
    resolver: zodResolver(calculatorSchema),
    defaultValues: initialValues,
  });

  // Form submission handler
  const handleSubmit = (values: CalculatorFormValues) => {
    setIsLoading(true);

    // Simulate delay to show loading state - would be a real API call in production
    setTimeout(() => {
      onCalculate(values);
      setHasCalculated(true);
      setIsLoading(false);
    }, 800);
  };

  // Save current calculation to local storage
  const saveCalculation = () => {
    const currentValues = form.getValues();
    const timestamp = new Date().toISOString();

    // Add a name for this saved calculation
    const name = prompt('Name this saved calculation:',
      `${currentValues.facilityType} - ${currentValues.bedCapacity} beds`);

    if (!name) return; // User cancelled

    const savedCalc = {
      id: timestamp,
      name,
      date: timestamp,
      values: currentValues
    };

    const updatedSaved = [...savedCalculations, savedCalc];
    setSavedCalculations(updatedSaved);

    // Save to localStorage
    if (typeof window !== 'undefined') {
      localStorage.setItem('savedROICalculations', JSON.stringify(updatedSaved));
    }
  };

  // Updated loadCalculation function to use Number.isNaN and template literals
  const loadCalculation = () => {
    if (savedCalculations.length === 0) {
      alert("No saved calculations found.");
      return;
    }

    const selectOptions = savedCalculations.map(calc => calc.name);

    const selectedOption = prompt(
      `Select a saved calculation to load:\n\n${selectOptions.map((opt, i) => `${i + 1}. ${opt}`).join('\n')}`
    );

    if (!selectedOption) return;

    // Try to parse the selection (either by number or name)
    const selectedIndex = Number.parseInt(selectedOption) - 1;
    if (!Number.isNaN(selectedIndex) && selectedIndex >= 0 && selectedIndex < savedCalculations.length) {
      form.reset(savedCalculations[selectedIndex].values);
      handleSubmit(savedCalculations[selectedIndex].values);
      return;
    }

    // If not found by index, try to find by name
    const foundByName = savedCalculations.find(calc => calc.name.toLowerCase() === selectedOption.toLowerCase());
    if (foundByName) {
      form.reset(foundByName.values);
      handleSubmit(foundByName.values);
      return;
    }

    alert("Calculation not found. Please try again.");
  };

  // Reset form to defaults
  const resetForm = () => {
    const confirmReset = confirm('Reset all values to defaults?');
    if (confirmReset) {
      form.reset(defaultValues);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Building className="mr-2 h-5 w-5 text-indigo-500" />
              Facility Information
            </CardTitle>
            <CardDescription>
              Tell us about your facility
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="facilityType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Facility Type</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select facility type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="residential">Residential Treatment</SelectItem>
                        <SelectItem value="detox">Detox Center</SelectItem>
                        <SelectItem value="php-iop">PHP/IOP Program</SelectItem>
                        <SelectItem value="outpatient">Outpatient Services</SelectItem>
                        <SelectItem value="specialty">Specialty Program</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="bedCapacity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Bed Capacity / Client Capacity
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        {...field}
                        min="1"
                        onChange={(e) => field.onChange(e.target.valueAsNumber)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="currentCensus"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Current Average Census (%)
                  </FormLabel>
                  <div className="flex items-center gap-4">
                    <FormControl>
                      <Slider
                        value={[field.value]}
                        onValueChange={(values) => field.onChange(values[0])}
                        max={100}
                        step={1}
                        className="flex-1"
                      />
                    </FormControl>
                    <span className="w-12 text-center">{field.value}%</span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="avgDailyRate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Average Daily Rate ($)
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="h-3.5 w-3.5 ml-1 text-slate-400 inline cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent side="right">
                          <p className="w-64 text-xs">The average amount you collect per day per client across all payers. For outpatient, use average per-visit rate.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      {...field}
                      min="0"
                      step="10"
                      onChange={(e) => field.onChange(e.target.valueAsNumber)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="avgLOS"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Average Length of Stay (days)
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="h-3.5 w-3.5 ml-1 text-slate-400 inline cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent side="right">
                          <p className="w-64 text-xs">For outpatient or PHP/IOP programs, use the average number of visits or sessions per client.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      {...field}
                      min="1"
                      onChange={(e) => field.onChange(e.target.valueAsNumber)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart className="mr-2 h-5 w-5 text-indigo-500" />
              Optimization Focus
            </CardTitle>
            <CardDescription>
              Select areas you want to improve
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="optimizeCensus"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between">
                    <div className="space-y-0">
                      <FormLabel className="font-normal flex items-center cursor-pointer">
                        <Users className="mr-1.5 h-4 w-4 text-indigo-500" />
                        Census Optimization
                      </FormLabel>
                      <FormDescription className="text-xs ml-6">
                        Increase average occupancy by up to 15%
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="optimizeReimbursement"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between">
                    <div className="space-y-0">
                      <FormLabel className="font-normal flex items-center cursor-pointer">
                        <DollarSign className="mr-1.5 h-4 w-4 text-indigo-500" />
                        Reimbursement Optimization
                      </FormLabel>
                      <FormDescription className="text-xs ml-6">
                        Improve daily rate by up to 10%
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="optimizeConversion"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between">
                    <div className="space-y-0">
                      <FormLabel className="font-normal flex items-center cursor-pointer">
                        <TrendingUp className="mr-1.5 h-4 w-4 text-indigo-500" />
                        Lead Conversion
                      </FormLabel>
                      <FormDescription className="text-xs ml-6">
                        Boost admissions by up to 12%
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="optimizeLOS"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between">
                    <div className="space-y-0">
                      <FormLabel className="font-normal flex items-center cursor-pointer">
                        <Building className="mr-1.5 h-4 w-4 text-indigo-500" />
                        Length of Stay Optimization
                      </FormLabel>
                      <FormDescription className="text-xs ml-6">
                        Increase appropriate LOS by up to 5%
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="optimizeOperations"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between">
                    <div className="space-y-0">
                      <FormLabel className="font-normal flex items-center cursor-pointer">
                        <BarChart className="mr-1.5 h-4 w-4 text-indigo-500" />
                        Operational Efficiency
                      </FormLabel>
                      <FormDescription className="text-xs ml-6">
                        Reduce costs by up to 8%
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-between gap-2 flex-wrap">
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={saveCalculation}
                disabled={!hasCalculated}
                className="flex items-center gap-1"
              >
                <Save className="h-3.5 w-3.5" />
                Save
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={loadCalculation}
                className="flex items-center gap-1"
              >
                <Upload className="h-3.5 w-3.5" />
                Load
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={resetForm}
                className="flex items-center gap-1"
              >
                <RotateCw className="h-3.5 w-3.5" />
                Reset
              </Button>
            </div>

            <Button
              type="submit"
              size="sm"
              disabled={isLoading}
              className="flex items-center gap-1"
            >
              {isLoading ? (
                <>
                  <RotateCw className="h-3.5 w-3.5 animate-spin" />
                  Calculating...
                </>
              ) : (
                <>
                  <Calculator className="h-3.5 w-3.5" />
                  Calculate ROI
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </Form>
  );
}
